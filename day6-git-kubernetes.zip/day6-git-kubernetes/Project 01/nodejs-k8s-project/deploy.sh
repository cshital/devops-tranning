#!/bin/bash

kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
kubectl apply -f service-nodeport.yaml